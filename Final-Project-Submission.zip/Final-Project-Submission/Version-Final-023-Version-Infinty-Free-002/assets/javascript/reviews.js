document.addEventListener("DOMContentLoaded", () => {
    const container  = document.getElementById("mediaContainer");
    const searchIn   = document.getElementById("searchInput");
    const typeFilter = document.getElementById("typeFilter");
    const sortOrder  = document.getElementById("sortOrder");

    if (!container) return;

    let allMedia = [];

    const normalize = (str) =>
        String(str || "").toLowerCase().trim();

    function render() {
        const q    = normalize(searchIn.value);
        const type = normalize(typeFilter.value);
        const sort = sortOrder.value || "title_asc";

        let list = [...allMedia];

        if (q) {
            list = list.filter(m =>
                normalize(m.media_title).includes(q)
            );
        }

        if (type) {
            list = list.filter(m =>
                normalize(m.media_type) === type
            );
        }

        list.sort((a, b) => {
            const at = normalize(a.media_title);
            const bt = normalize(b.media_title);
            return sort === "title_desc"
                ? bt.localeCompare(at)
                : at.localeCompare(bt);
        });

        if (list.length === 0) {
            container.innerHTML = "<p>No media found.</p>";
            return;
        }

        container.innerHTML = "";

        list.forEach(item => {
            const img = item.media_image || "no-image.jpg";
            const avg = Number(item.average_rating || 0);
            const avgText = isFinite(avg) ? avg.toFixed(1) : "0.0";

            container.insertAdjacentHTML("beforeend", `
                <div class="media-card">
                    <img
                        class="media-image"
                        src="/assets/images/${img}"
                        alt="${item.media_title}"
                        onerror="this.onerror=null;this.src='/assets/images/no-image.jpg';"
                    >

                    <div class="media-info">
                        <h3>${item.media_title}</h3>

                        <p class="media-type">
                            <strong>Type:</strong> ${item.media_type}
                        </p>

                        <p class="media-description">
                            <strong>Genre:</strong> ${item.genre_name || "N/A"}
                        </p>

                        <p class="media-rating">
                            <strong>Rating:</strong> ${avgText}
                        </p>

                        <a
                            class="btn-details"
                            href="/index.php?page=media-details&media_id=${item.media_id}"
                        >
                            View Details
                        </a>
                    </div>
                </div>
            `);
        });
    }

    fetch("/router/router.php?action=getMedia")
        .then(res => res.json())
        .then(data => {
            if (!data.success || !Array.isArray(data.media)) {
                container.innerHTML = "<p>Error loading media.</p>";
                return;
            }

            allMedia = data.media;
            render();
        })
        .catch(() => {
            container.innerHTML = "<p>Error loading media.</p>";
        });

    searchIn.addEventListener("input", render);
    typeFilter.addEventListener("change", render);
    sortOrder.addEventListener("change", render);
});
